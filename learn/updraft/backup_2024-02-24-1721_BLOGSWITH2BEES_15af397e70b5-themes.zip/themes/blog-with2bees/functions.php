<?php
// // this adds the style.css file so we can do our styling there, and not in the dumb-ass side panel of the FSE
function with2bees_styles() {
    wp_enqueue_style( 'style.css', get_stylesheet_uri()	);
}
add_action( 'wp_enqueue_scripts', 'with2bees_styles' );

// adds an editor link directly to the side panel (not in the appearance menu...)
function add_custom_menu_link() {
	add_menu_page('Full Site Editor', 'Editor', 'read', 'https://learn.with2bees.com/wp-admin/site-editor.php', '', 'dashicons-admin-appearance', 1);
}
add_action('admin_menu', 'add_custom_menu_link');

// admin menu recolor (dark mode)
function applyCustomStyles() {
    echo '
    <style>
    /*                          **
    **  Default Customizations  **
    **                          */
    #wpbody-content a { filter: invert(1) hue-rotate(180deg) saturate(10); color: white !important; }
    #wpbody-content a:hover { filter: invert(1) hue-rotate(180deg) saturate(10); color: blue !important; }
    .block-editor-page .editor-styles-wrapper { color: lightgray; background-color: #212836; }
    .wp-admin { background-color: #212836; }
    .wp-admin #wpbody img { filter: invert(1) hue-rotate(-180deg); background: white; }
    .block-editor-page .editor-styles-wrapper a { filter: invert(0.85) hue-rotate(185deg); }
    .block-editor-page #wpbody { filter: unset; }
    .block-editor-page .interface-interface-skeleton__sidebar, .block-editor-page .interface-interface-skeleton__secondary-sidebar { filter: invert(0.85) hue-rotate(185deg); }
    .block-editor-page .interface-interface-skeleton__header { filter: invert(0.85) hue-rotate(185deg); }
    .block-editor-page .is-primary { color: black !important; }
    .block-editor-page .edit-post-layout__metaboxes { border-top: 0px; background-color: #212836; }
    .wrap .add-new-h2, .wrap .add-new-h2:active, .wrap .page-title-action, .wrap .page-title-action:active { background:#f6f7f700; }
    #wpbody { /* filter: invert(0.85) hue-rotate(185deg); */ }
    
    /*                       **
    **   My customizations   **
    **                       */
    #wpfooter { display: none; }
    #wpbody-content p { color: rgba(255,255,255,0.85); }
    #wpbody-content h1, #wpbody-content h2 { color: #6680CC !important; }
    #adminmenuwrap, #adminmenuback, #adminmenu, .wp-filter { background-color: #1c212e !important; border-color: black; }
    #wpadminbar { background-color: #0e1017 !important; }
    .wp-submenu.wp-submenu-wrap { background-color: rgba(0,0,0,0.5) !important; }
    .opensub { background-color: white !important; }
    #adminmenu li:hover { background-color: rgba(0,0,0,0.5) !important; }
    .wp-list-table { border-color: #000 !important; }
    .wp-list-table { margin-top: 20px !important; }
    #wpbody table tr:nth-child(odd) { background-color: #1c212e; }
    #wpbody table tr:nth-child(even) { background-color: #212836; }
    #wpbody table a { color: rgba(0,0,0,0.75) !important; font-weight: 400; }
    #wpbody table input { background-color: rgba(0,0,0,0.5); border-color: black; }
    table label, table th { color: white !important; }
    #wpbody-content li a { color: black !important; }
    #wpbody-content h1 { color: rgba(255,255,255,0.75); }
    #screen-meta-links { display: none; }
    #the-list td, #the-list tr, #the-list p { color: rgba(255,255,255,0.85) !important; }
    
    img:not(.components-responsive-wrapper__content) { filter: invert(0) !important; }

    

    .edit-site-header-edit-mode { background-color: #212836 !important; border-color: black !important; }
    .edit-site-document-actions.is-synced-entity { background-color: #1c212e; }
    .edit-site-document-actions.is-synced-entity:hover { background-color: #212836 !important; }
    .edit-site-header-edit-mode svg { fill: white !important; }
    .interface-interface-skeleton__footer { background-color: black !important; }
    .empty-container { outline: 1px dashed rgba(255,255,255,0.2) !important; }
    .next-page.button, .last-page.button, .prev-page.button, .first-page.button { filter: invert(0) !important; }
    .button.disabled, .button.disabled, .button.disabled, .button.disabled { display: none !important; }
    .media-toolbar { background-color: #1c212e !important; border-color: black !important; }
    .form-field label, #col-left h2 { color: rgba(255,255,255,0.85); text-transform: uppercase; font-weight: bold; }
    .tablenav .button:hover, .tablenav .button.disabled, .tablenav a:hover, #search-submit.button:hover, #submit.button:hover { background-color: rgba(0,0,0,0.5) !important; }
    .tablenav-pages .button { background-color: white !important; border-color: white !important; }
    
    .theme-browser { filter: invert(0) !important; }

    .theme.active { border-color: black !important; }
    
    .theme-browser .theme.active .theme-name { background-color: #000 !important; }
    
    .widefat thead td, .widefat thead th, .widefat tfoot td, .widefat tfoot th {
        background-color: rgba(0,0,0,0.5);
        border-color: black;
        color: rgba(255,255,255,0.5) !important;
        text-transform: uppercase;
        font-weight: bold;
        font-size: 12px;
        padding-top: 10px;
        padding-bottom: 10px;
    }
    .tablenav select, .tablenav input, .search-box input, form input, form select, form textarea, table select, table input, .media-toolbar select, .media-toolbar input, .search-form input, #media-search-input {
        background-color: rgba(0,0,0,0.5); !important;
        border-color: black !important;
        color: rgba(255,255,255,0.75) !important;
        padding: 6px 14px;
    }
    .tablenav .button, .tablenav .button.disabled, .tablenav a, #search-submit.button, #submit.button, .media-toolbar button, .next-page.button, .last-page.button, .prev-page.button, .first-page.button {
        background-color: #1c212e !important;
        border-color: black !important;
        color: white;
        padding: 6px 14px;
    }
    .theme-actions { background-color: transparent !important; }
    .theme-actions .button {
        filter: invert(0) !important;
        background-color: #1c212e !important;
        border-color: black !important;
        color: white;
        padding: 6px 16px;
    }
    .page-title-action {
        background-color: rgba(0,0,0,0.5) !important;
        border-color: black !important;
        padding: 6px 10px !important;
        filter: invert(0) !important;
        display: none !important;
    }
    #the-list .active, #the-list .active td, #the-list .active th {
        filter: invert(0) !important;
        background-color: #212836 !important;
        color: white !important;
    }
    </style>';
}
add_action('admin_head', 'applyCustomStyles');

?>